//
//  MovieSearchView.swift
//  TheMovie
//
//  Created by Ryan Aditya on 20/09/20.
//  Copyright © 2020 Ryan Aditya. All rights reserved.
//

import SwiftUI

struct MovieSearchView: View {
    
    @ObservedObject var movieSearch = Movie_Search()
    
        var body: some View {
            NavigationView {
                List {
                    SearchBar_View(placeholder: "Search movies", text: self.$movieSearch.query)
                        .listRowInsets(EdgeInsets(top: 0, leading: 8, bottom: 0, trailing: 8))
                    
                    Loading_View(isLoading: self.movieSearch.isLoading, error: self.movieSearch.error) {
                        self.movieSearch.search(query: self.movieSearch.query)
                    }
                    
                    if self.movieSearch.movies != nil {
                        ForEach(self.movieSearch.movies!) { movie in
                            NavigationLink(destination: MovieDetailView(movieId: movie.id)) {
                                VStack(alignment: .leading) {
                                    Text(movie.title)
                                    Text(movie.yearText)
                                }
                            }
                        }
                    }
                    
                }
                .onAppear {
                    self.movieSearch.startObserve()
                }
                .navigationBarTitle("Search")
            }
        }
    }

    struct MovieSearchView_Previews: PreviewProvider {
        static var previews: some View {
            MovieSearchView()
        }
}
