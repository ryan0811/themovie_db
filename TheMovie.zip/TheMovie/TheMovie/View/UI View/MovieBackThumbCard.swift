//
//  MovieBackThumbCard.swift
//  TheMovie
//
//  Created by Ryan Aditya on 19/09/20.
//  Copyright © 2020 Ryan Aditya. All rights reserved.
//

import SwiftUI

struct MovieBackThumbCard: View {
    
    let movie: Movie_Model
    @ObservedObject var imageLoader = Load_Image()
    
    var body: some View {
        VStack(alignment: .leading) {
            ZStack {
                Rectangle()
                    .fill(Color.gray.opacity(0.3))
                
                if self.imageLoader.image != nil {
                    Image(uiImage: self.imageLoader.image!)
                    .resizable()
                }
            }
            .aspectRatio(16/9, contentMode: .fit)
            .cornerRadius(8)
            .shadow(radius: 4)
            
            Text(movie.title)
        }
        .lineLimit(1)
        .onAppear {
            self.imageLoader.loadImage(with: self.movie.backdropURL)
        }
    }
}

struct MovieBackThumbCard_Preview: PreviewProvider {
    static var previews: some View {
        MovieBackThumbCard(movie: Movie_Model.bundleMovies)
    }
}

