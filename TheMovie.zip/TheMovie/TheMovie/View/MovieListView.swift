//
//  MovieListView.swift
//  TheMovie
//
//  Created by Ryan Aditya on 19/09/20.
//  Copyright © 2020 Ryan Aditya. All rights reserved.
//

import SwiftUI

struct MovieListView: View {
    
    @ObservedObject private var nowPlayingState = Movie_List()
    @ObservedObject private var upcomingState = Movie_List()
    @ObservedObject private var topRatedState = Movie_List()
    @ObservedObject private var popularState = Movie_List()
    

    var body: some View {
        NavigationView {
            List {
                Group {
                    if nowPlayingState.movies != nil {
                        MovieThumbnailView(title: "Now Playing", movies: nowPlayingState.movies!)
                        
                    } else {
                        Loading_View(isLoading: self.nowPlayingState.isLoading, error: self.nowPlayingState.error) {
                            self.nowPlayingState.loadMovies(with: .nowPlaying)
                        }
                    }
                    
                }
                .listRowInsets(EdgeInsets(top: 16, leading: 0, bottom: 16, trailing: 0))
                
                Group {
                    if upcomingState.movies != nil {
                        MovieBackThumbView(title: "Action", movies: upcomingState.movies!)
                    } else {
                        Loading_View(isLoading: self.upcomingState.isLoading, error: self.upcomingState.error) {
                            self.upcomingState.loadMovies(with: .upcoming)
                        }
                    }
                }
                .listRowInsets(EdgeInsets(top: 8, leading: 0, bottom: 8, trailing: 0))
                
                
                Group {
                    if popularState.movies != nil {
                        MovieBackThumbView(title: "Crime", movies: popularState.movies!)
                        
                    } else {
                        Loading_View(isLoading: self.topRatedState.isLoading, error: self.popularState.error) {
                            self.topRatedState.loadMovies(with: .topRated)
                        }
                    }
                    
                    
                }
                .listRowInsets(EdgeInsets(top: 8, leading: 0, bottom: 8, trailing: 0))
                
                Group {
                    if topRatedState.movies != nil {
                        MovieBackThumbView(title: "Drama", movies: topRatedState.movies!)
                        
                    } else {
                        Loading_View(isLoading: self.topRatedState.isLoading, error: self.topRatedState.error) {
                            self.topRatedState.loadMovies(with: .topRated)
                        }
                    }
                }
                .listRowInsets(EdgeInsets(top: 8, leading: 0, bottom: 16, trailing: 0))
                
                
                
            }
            .navigationBarTitle("The Movie")
        }
        .onAppear {
            self.nowPlayingState.loadMovies(with: .nowPlaying)
            self.upcomingState.loadMovies(with: .upcoming)
            self.topRatedState.loadMovies(with: .topRated)
            self.popularState.loadMovies(with: .popular)
        }
        
    }
}

struct MovieListView_Previews: PreviewProvider {
    static var previews: some View {
        MovieListView()
    }
}


