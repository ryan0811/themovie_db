//
//  Movie_Bundle.swift
//  TheMovie
//
//  Created by Ryan Aditya on 19/09/20.
//  Copyright © 2020 Ryan Aditya. All rights reserved.
//

import Foundation


extension Movie_Model {
    
    static var bundleMovie: [Movie_Model] {
        let response: MovieResponse? = try? Bundle.main.loadAndDecodeJSON(filename: "movie_list")
        return response!.results
    }
    
    static var bundleMovies: Movie_Model {
        bundleMovie[0]
    }
    
//    static var bundleGenre: [Movie_Model]{
//        let respomse: MovieResponse? = try
//    }
    
}
extension Bundle {
    
    func loadAndDecodeJSON<Decode: Decodable>(filename: String) throws -> Decode? {
        guard let url = self.url(forResource: filename, withExtension: "json") else {
            return nil
        }
        let data = try Data(contentsOf: url)
        let jsonDecoder = Utils.jsonDecoder
        let decodedModel = try jsonDecoder.decode(Decode.self, from: data)
        return decodedModel
    }
    
//    func genreAndLoad<Decode: Decodable>(filename: String)-> Decode? {
    
    //      Client.Genres(api_key, listType: listType.rawValue, language: language, genreId: 0, page: nil, include_all_movies: nil, include_adult: nil, movieList: false){
    //        apiReturn in
    //        if(apiReturn.error == nil){
    //          completion(apiReturn, GenresMDB.initialize(json: apiReturn.json!["genres"]))
    //        }else{
    //          completion(apiReturn, nil)
    //        }
//    }
    
}
