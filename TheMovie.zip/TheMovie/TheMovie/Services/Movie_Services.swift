//
//  Movie_Services.swift
//  TheMovie
//
//  Created by Ryan Aditya on 19/09/20.
//  Copyright © 2020 Ryan Aditya. All rights reserved.
//

import Foundation

protocol Movie_Services {
    
    func fetchMovies(from endpoint: MovieEndpoint, completion: @escaping (Result<MovieResponse, MovieError>) -> ())
    func fetchMovie(id: Int, completion: @escaping (Result<Movie_Model, MovieError>) -> ())
    func searchMovie(query: String, completion: @escaping (Result<MovieResponse, MovieError>) -> ())
}

enum MovieEndpoint: String, CaseIterable, Identifiable {
    
    var id: String { rawValue }
    
    case nowPlaying = "now_playing"
    case upcoming
    case topRated = "top_rated"
    case popular
    
    var description: String {
        switch self {
            case .nowPlaying: return "Now Playing"
            case .upcoming: return "Upcoming"
            case .topRated: return "Top Rated"
            case .popular: return "Popular"
        }
    }
}

enum Category: String, CaseIterable, Hashable {

    case marvel = "Marvel"
    case dc = "DC"
    case actionAdventure = "Action"
    case horor = "Horor"
    
    var description: String {
        switch self {
            case .marvel: return "Marvel"
            case .dc: return "DC"
            case .actionAdventure: return "Action"
            case .horor: return "Horor"
        }
    }
}

enum MovieError: Error, CustomNSError {
    
    case apiError
    case invalidEndpoint
    case invalidResponse
    case noData
    case serializationError
    
    var localizedDescription: String {
        switch self {
        case .apiError: return "Failed to fetch data"
        case .invalidEndpoint: return "Invalid endpoint"
        case .invalidResponse: return "Invalid response"
        case .noData: return "No data"
        case .serializationError: return "Failed to decode data"
        }
    }
    
    var errorUserInfo: [String : Any] {
        [NSLocalizedDescriptionKey: localizedDescription]
    }
    
}

