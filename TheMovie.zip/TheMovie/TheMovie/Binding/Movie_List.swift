//
//  Movie_List.swift
//  TheMovie
//
//  Created by Ryan Aditya on 19/09/20.
//  Copyright © 2020 Ryan Aditya. All rights reserved.
//

import SwiftUI

class Movie_List: ObservableObject {
    
    @Published var movies: [Movie_Model]?
    @Published var isLoading: Bool = false
    @Published var error: NSError?

    private let movieService: Movie_Services
    
    init(movieService: Movie_Services = Movie_Store.shared) {
        self.movieService = movieService
    }
    
    func loadMovies(with endpoint: MovieEndpoint) {
        self.movies = nil
        self.isLoading = true
        self.movieService.fetchMovies(from: endpoint) { [weak self] (result) in
            guard let self = self else { return }
            self.isLoading = false
            switch result {
            case .success(let response):
                self.movies = response.results
                
            case .failure(let error):
                self.error = error as NSError
            }
        }
    }
    
}

