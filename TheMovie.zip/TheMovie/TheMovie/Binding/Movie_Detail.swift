//
//  Movie_Detail.swift
//  TheMovie
//
//  Created by Ryan Aditya on 20/09/20.
//  Copyright © 2020 Ryan Aditya. All rights reserved.
//

import SwiftUI

class Movie_Detail: ObservableObject {
    
    private let movieService: Movie_Services
    @Published var movie: Movie_Model?
    @Published var isLoading = false
    @Published var error: NSError?
    
    init(movieService: Movie_Services = Movie_Store.shared) {
        self.movieService = movieService
    }
    
    func loadMovie(id: Int) {
        self.movie = nil
        self.isLoading = false
        self.movieService.fetchMovie(id: id) {[weak self] (result) in
            guard let self = self else { return }
            
            self.isLoading = false
            switch result {
            case .success(let movie):
                self.movie = movie
            case .failure(let error):
                self.error = error as NSError
            }
        }
    }
}
